import {readFile,readdir,mkdir,writeFile,rm} from 'node:fs/promises';
const pages={};for(const name of await readdir('pages'))if(name.endsWith('.html'))pages['/'+name]=await readFile('pages/'+name,'utf8');
const assets={};for(const name of await readdir('assets')){const type=name.endsWith('.webp')?'image/webp':name.endsWith('.jpg')?'image/jpeg':'application/octet-stream';assets['/assets/'+name]={type,data:(await readFile('assets/'+name)).toString('base64')}}
await writeFile('worker/pages.js','export const pages = '+JSON.stringify(pages)+';\n');
const worker=await readFile('worker/index.js','utf8');const bundled=worker.replace("import { pages } from './pages.js';",'const pages = '+JSON.stringify(pages)+';const assets = '+JSON.stringify(assets)+';');
await rm('dist',{recursive:true,force:true});await mkdir('dist/server',{recursive:true});await mkdir('dist/.openai',{recursive:true});await writeFile('dist/server/index.js',bundled);await writeFile('dist/.openai/hosting.json',await readFile('.openai/hosting.json'));console.log('Built five unified pages, images and MCP routes.');
