import { pages } from './pages.js';
const endpoint='https://mcp-service-public.nhaultcoeur.workers.dev/mcp';
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
export async function callMcp(name,args){
 const response=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json, text/event-stream'},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/call',params:{name,arguments:args}}),signal:AbortSignal.timeout(20000)});
 if(!response.ok)throw new Error('MCP unavailable');
 const raw=await response.text();let payload;
 if(response.headers.get('Content-Type')?.includes('text/event-stream')){const messages=raw.split('\n').filter(l=>l.startsWith('data:')).map(l=>{try{return JSON.parse(l.slice(5).trim())}catch{return null}});payload=messages.find(x=>x?.id===1)}else payload=JSON.parse(raw);
 if(!payload?.result||payload.error||payload.result.isError)throw new Error('MCP error');
 return (payload.result.content||[]).filter(c=>c.type==='text').map(c=>c.text).join('\n');
}
export function safeUrl(value){try{const u=new URL(value);return u.protocol==='https:'&&['www.service-public.fr','service-public.fr','www.service-public.gouv.fr','service-public.gouv.fr'].includes(u.hostname)?u.href:null}catch{return null}}
export function parseResults(text){
 return text.split(/\n## /).slice(1).map(block=>{const lines=block.split('\n');const id=block.match(/\*\*ID\*\*\s*:\s*([FNR]\d+)/)?.[1];const url=safeUrl(block.match(/\*\*URL\*\*\s*:\s*(https:\/\/\S+)/)?.[1]);const title=lines[0].trim();const description=lines.slice(1).filter(x=>!/^\*\*(ID|URL)\*\*/.test(x)&&!/^---/.test(x)).join('\n').trim();return {id,title,url,description}}).filter(x=>x.id&&x.url&&x.title).slice(0,8);
}
export default {async fetch(request){const url=new URL(request.url);if(request.method!=='GET'&&request.method!=='HEAD')return json({error:'Méthode non autorisée.'},405);
 if(url.pathname.startsWith('/api/demarches/')){try{
  if(url.pathname==='/api/demarches/search'){const q=(url.searchParams.get('q')||'').trim();if(q.length<2||q.length>180)return json({error:'Saisissez entre 2 et 180 caractères.'},400);const content=await callMcp('rechercher_fiche',{query:q,limit:6});return json({query:q,results:parseResults(content)})}
  if(url.pathname==='/api/demarches/local'){const commune=(url.searchParams.get('commune')||'').trim();const type=url.searchParams.get('type')||'france_services';if(commune.length<2||commune.length>80||!['france_services','mairie','caf','cpam','france_travail','prefecture'].includes(type))return json({error:'Indiquez une commune et un type d’organisme valides.'},400);const args={type_organisme:type,limit:4};if(/^\d{5}$/.test(commune))args.code_postal=commune;else args.commune=commune;const text=await callMcp('rechercher_service_local',args);return json({text:text.slice(0,18000)})}
  if(url.pathname==='/api/demarches/fiche'){const id=url.searchParams.get('id')||'';if(!/^[FNR]\d{1,10}$/.test(id))return json({error:'Référence de fiche invalide.'},400);const text=await callMcp('lire_fiche',{fiche_id:id});const updated=text.match(/\*\*Mise à jour\*\*\s*:\s*(?:modified\s*)?([^\n]+)/)?.[1]?.trim()||null;const content=text.split(/## Contenu\s*\n/)[1]||text;return json({id,updated,text:content.slice(0,16000)})}
  return json({error:'Ressource introuvable.'},404);
 }catch{return json({error:'La recherche est momentanément indisponible. Réessayez dans un instant.'},503)}}
 if(assets[url.pathname]){const a=assets[url.pathname];return new Response(request.method==='HEAD'?null:Uint8Array.from(atob(a.data),c=>c.charCodeAt(0)),{headers:{'Content-Type':a.type,'Cache-Control':'public,max-age=3600','X-Content-Type-Options':'nosniff'}})}
 let route=url.pathname.replace(/\/$/,'')||'/';if(route==='/')route='/index.html';if(!route.endsWith('.html'))route+='.html';const html=pages[route];if(!html)return new Response('Page introuvable',{status:404});return new Response(request.method==='HEAD'?null:html,{headers:{'Content-Type':'text/html; charset=utf-8','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin'}});
}};
