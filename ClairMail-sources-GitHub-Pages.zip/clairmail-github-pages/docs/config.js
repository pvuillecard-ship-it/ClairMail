// Adresse HTTPS du serveur API séparé. Laisser vide tant qu’il n’est pas déployé.
// Exemple à remplacer : https://clairmail-demarches-api.VOTRE-SOUS-DOMAINE.workers.dev
// Ne jamais mettre de clé API ou de secret dans ce fichier public.
window.CLAIRMAIL_CONFIG = { apiBaseUrl: "" };
